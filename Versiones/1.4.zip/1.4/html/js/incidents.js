/* Initialize functionality on page load */
document.addEventListener('DOMContentLoaded', () => {
    const menuIcon = document.getElementById('menuIcon');
    const sidebar = document.getElementById('sidebar');

    // Check if elements exist
    if (!menuIcon || !sidebar) {
        console.error('Menu icon or sidebar not found');
        return;
    }

    // Handle menu icon click: toggle sidebar or scroll to top
    menuIcon.addEventListener('click', (e) => {
        e.preventDefault();
        if (sidebar.classList.contains('active')) {
            // Close sidebar
            sidebar.classList.remove('active');
            sidebar.classList.add('hidden');
            menuIcon.textContent = window.pageYOffset > 100 ? '↑' : '☰';
            menuIcon.classList.toggle('scroll-to-top', window.pageYOffset > 100);
            menuIcon.classList.add('active');
        } else if (window.pageYOffset > 100) {
            // Scroll to top
            window.scrollTo({ top: 0, behavior: 'smooth' });
            sidebar.classList.add('hidden');
            menuIcon.textContent = '↑';
            menuIcon.classList.add('scroll-to-top', 'active');
        } else {
            // Open sidebar
            sidebar.classList.add('active');
            sidebar.classList.remove('hidden');
            menuIcon.textContent = '✕';
            menuIcon.classList.remove('scroll-to-top');
            menuIcon.classList.add('active');
        }
    });

    // Handle scroll: hide sidebar and show menu icon on scroll down
    let lastScrollTop = 0;
    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset || document.documentElement.scrollTop;
        if (currentScroll > lastScrollTop && currentScroll > 100) {
            // Scroll down past 100px: hide sidebar, show menu icon
            sidebar.classList.add('hidden');
            sidebar.classList.remove('active');
            menuIcon.classList.add('active', 'scroll-to-top');
            menuIcon.textContent = '↑';
        } else {
            // Scroll up or near top: show sidebar, hide menu icon
            sidebar.classList.remove('hidden', 'active');
            menuIcon.classList.remove('active', 'scroll-to-top');
            menuIcon.textContent = '☰';
        }
        lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
    });

    // Handle resize: ensure consistent state
    window.addEventListener('resize', () => {
        if (window.pageYOffset > 100) {
            sidebar.classList.add('hidden');
            sidebar.classList.remove('active');
            menuIcon.classList.add('active', 'scroll-to-top');
            menuIcon.textContent = '↑';
        } else {
            sidebar.classList.remove('hidden', 'active');
            menuIcon.classList.remove('active', 'scroll-to-top');
            menuIcon.textContent = '☰';
        }
    });

    // Set initial state
    if (window.pageYOffset > 100) {
        sidebar.classList.add('hidden');
        menuIcon.classList.add('active', 'scroll-to-top');
        menuIcon.textContent = '↑';
    }
});

// Modal functions
function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// Placeholder form submission handlers
document.getElementById('create-incident-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Incidencia creada (funcionalidad placeholder)');
    closeModal('create-incident-modal');
});

document.getElementById('update-incident-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Incidencia actualizada (funcionalidad placeholder)');
    closeModal('update-incident-modal');
});