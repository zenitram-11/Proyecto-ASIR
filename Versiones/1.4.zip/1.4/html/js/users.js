// js/users.js
// Lógica específica para la página de gestión de usuarios

document.addEventListener('DOMContentLoaded', () => {
    // Elementos de la interfaz
    const listUsersBtn = document.getElementById('listUsersBtn');
    const usersTableContainer = document.getElementById('users-table'); // Contenedor de tarjetas

    const showCreateUserFormBtn = document.getElementById('showCreateUserFormBtn');
    const cancelCreateUserBtn = document.getElementById('cancelCreateUserBtn');
    const createUserForm = document.getElementById('createUserForm');

    const cancelUpdateUserBtn = document.getElementById('cancelUpdateUserBtn');
    const updateUserForm = document.getElementById('updateUserForm');
    const updateUserIdInput = document.getElementById('update_user_id');

    // Secciones para mostrar/ocultar (solo lista, ya que formularios son modales)
    const sections = {
        list: document.getElementById('list-users-section'),
    };

    /**
     * Muestra una sección específica y oculta las otras.
     * @param {string} sectionId El ID de la sección a mostrar ('list').
     */
    function showSection(sectionId) {
        // Ocultar todas las secciones
        for (const key in sections) {
            if (sections[key]) {
                sections[key].style.display = 'none';
            }
        }

        // Mostrar la sección solicitada
        const sectionToShow = sections[sectionId];
        if (sectionToShow) {
            sectionToShow.style.display = 'block';
        } else {
            console.error(`Sección con ID "${sectionId}" no encontrada.`);
        }

        // Ocultar mensajes de estado al cambiar de sección
        hideStatusMessage();
    }

    // --- Funciones para cargar y renderizar datos ---

    /**
     * Carga todos los usuarios desde la API y actualiza la lista de tarjetas.
     */
    async function loadUsers() {
        if (usersTableContainer) {
            usersTableContainer.innerHTML = '<div class="user-card"><div class="user-id">Cargando usuarios...</div></div>';
        }
        const data = await fetchData('/users', 'GET');

        if (data && data.error) {
            if (usersTableContainer) {
                usersTableContainer.innerHTML = `<div class="user-card"><div class="user-id" style="color:red;">Error al cargar usuarios: ${data.error.message || data.error}</div></div>`;
            }
        } else if (Array.isArray(data)) {
            renderUsers(data);
        } else {
            if (usersTableContainer) {
                usersTableContainer.innerHTML = `<div class="user-card"><div class="user-id" style="color:orange;">Respuesta de API inesperada.</div></div>`;
            }
            console.warn("Unexpected API response for /users:", data);
        }
        showSection('list');
    }

    /**
     * Rellena el contenedor con tarjetas de usuarios.
     * @param {Array<object>} users Lista de objetos usuario.
     */
    function renderUsers(users) {
        if (!usersTableContainer) return;

        usersTableContainer.innerHTML = '';

        if (users.length === 0) {
            usersTableContainer.innerHTML = '<div class="user-card"><div class="user-id">No hay usuarios registrados.</div></div>';
            return;
        }

        users.forEach(user => {
            const card = document.createElement('div');
            card.className = 'user-card';
            card.setAttribute('data-id', user.user_id);
            card.innerHTML = `
                <div class="user-id">ID: ${user.user_id}</div>
                <div class="user-name">${user.name}</div>
                <div class="user-email">${user.email}</div>
                <div class="user-created">${user.created_at ? new Date(user.created_at + 'Z').toLocaleString() : 'N/A'}</div>
                <div class="user-actions">
                    <button class="btn btn-sm btn-warning edit-btn" data-id="${user.user_id}">Editar</button>
                    <button class="btn btn-sm btn-danger delete-btn" data-id="${user.user_id}">Eliminar</button>
                </div>
            `;
            usersTableContainer.appendChild(card);
        });
    }

    // --- Manejo de Formularios ---

    // Formulario de Creación de Usuario
    if (createUserForm) {
        createUserForm.addEventListener('submit', async function(event) {
            event.preventDefault();

            const formData = new FormData(this);
            const data = {
                name: formData.get('name'),
                email: formData.get('email'),
            };

            // Validaciones básicas en frontend
            if (!data.name || !data.email) {
                showStatusMessage("Nombre e email son campos requeridos.", 'error');
                return;
            }
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(data.email)) {
                showStatusMessage("Formato de email inválido.", 'error');
                return;
            }

            const result = await fetchData('/users', 'POST', data);

            if (result && result.error) {
                // Error mostrado por fetchData
            } else if (result && result.user_id) {
                showStatusMessage('Usuario creado con éxito.', 'success');
                alert('Usuario creado con ID: ' + result.user_id);
                this.reset();
                closeModal('create-user-modal');
                loadUsers();
            } else {
                showStatusMessage('Respuesta inesperada al crear usuario.', 'error');
                console.warn("Unexpected successful API response for POST /users:", result);
            }
        });
    } else {
        console.error("Formulario 'createUserForm' no encontrado.");
    }

    // Formulario de Actualización de Usuario
    if (updateUserForm) {
        updateUserForm.addEventListener('submit', async function(event) {
            event.preventDefault();

            const userId = updateUserIdInput.value;
            if (!userId || parseInt(userId) <= 0) {
                showStatusMessage("ID de usuario para actualizar inválido.", 'error');
                return;
            }

            const formData = new FormData(this);
            const dataToUpdate = {};
            let hasData = false;

            const name = formData.get('name');
            if (name !== "") {
                dataToUpdate.name = name;
                hasData = true;
            }

            const email = formData.get('email');
            if (email !== "") {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email)) {
                    showStatusMessage("Formato de email inválido.", 'error');
                    return;
                }
                dataToUpdate.email = email;
                hasData = true;
            }

            if (!hasData) {
                showStatusMessage("No hay datos válidos para actualizar.", 'error');
                return;
            }

            const result = await fetchData(`/users/${userId}`, 'PUT', dataToUpdate);

            if (result && result.error) {
                // Error mostrado por fetchData
            } else {
                showStatusMessage('Usuario actualizado con éxito.', 'success');
                alert('Usuario actualizado.');
                this.reset();
                closeModal('update-user-modal');
                loadUsers();
            }
        });
    } else {
        console.error("Formulario 'updateUserForm' no encontrado.");
    }

    // --- Manejo de Botones en las Tarjetas ---
    if (usersTableContainer) {
        usersTableContainer.addEventListener('click', async function(event) {
            const target = event.target;
            const button = target.closest('.edit-btn, .delete-btn');

            if (!button) return;

            const userId = button.getAttribute('data-id');

            if (!userId) {
                console.error("Botón clicado sin data-id");
                return;
            }

            if (button.classList.contains('edit-btn')) {
                showStatusMessage(`Cargando datos de usuario ${userId} para editar...`, 'success');
                const userData = await fetchData(`/users/${userId}`, 'GET');

                if (userData && userData.error) {
                    // Error mostrado por fetchData
                } else if (userData) {
                    document.getElementById('update_user_id').value = userData.user_id;
                    document.getElementById('update_user_name').value = userData.name || '';
                    document.getElementById('update_user_email').value = userData.email || '';
                    openModal('update-user-modal');
                } else {
                    showStatusMessage('Respuesta inesperada al cargar datos para editar.', 'error');
                    console.warn("Unexpected successful API response for GET /users/{id} for edit:", userData);
                }
            } else if (button.classList.contains('delete-btn')) {
                if (confirm(`¿Estás seguro de eliminar al usuario con ID ${userId}? Esta acción puede fallar si el usuario tiene incidencias asociadas.`)) {
                    const result = await fetchData(`/users/${userId}`, 'DELETE');
                    if (result && result.error) {
                        // Error mostrado por fetchData
                    } else {
                        showStatusMessage('Usuario eliminado con éxito.', 'success');
                        alert('Usuario eliminado.');
                        loadUsers();
                    }
                }
            }
        });
    } else {
        console.error("Elemento 'usersTableContainer' no encontrado.");
    }

    // --- Listeners de Botones ---

    // Botón "Actualizar Listado"
    if (listUsersBtn) {
        listUsersBtn.addEventListener('click', () => {
            loadUsers();
        });
    } else {
        console.error("Botón 'listUsersBtn' no encontrado.");
    }

    // --- Inicialización ---
    loadUsers();
});