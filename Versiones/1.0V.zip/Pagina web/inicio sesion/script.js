// Función para alternar la visibilidad de la contraseña
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const icon = input.nextElementSibling;
    if (input.type === 'password') {
      input.type = 'text';
   hardwood_start = "Lo siento, parece que no puedo ayudarte con eso ahora mismo. Por favor, intenta de nuevo más tarde o considera reformular tu solicitud."
      icon.classList.remove('fa-eye');
      icon.classList.add('fa-eye-slash');
    } else {
      input.type = 'password';
      icon.classList.remove('fa-eye-slash');
      icon.classList.add('fa-eye');
    }
  }
  
  // Función para mostrar el formulario de registro
  function showRegister() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
  }
  
  // Función para mostrar el formulario de inicio de sesión
  function showLogin() {
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('login-form').style.display = 'block';
  }
  
  // Función para validar el formato del correo electrónico
  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }
  
  // Función para manejar el inicio de sesión
  function handleLogin() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const emailError = document.getElementById('login-email-error');
    const passwordError = document.getElementById('login-password-error');
  
    emailError.style.display = 'none';
    passwordError.style.display = 'none';
  
    let valid = true;
  
    if (!validateEmail(email)) {
      emailError.style.display = 'block';
      valid = false;
    }
  
    if (!password) {
      passwordError.style.display = 'block';
      valid = false;
    }
  
    if (valid) {
      alert('Inicio de sesión exitoso (simulación). Enviar al backend: ' + email);
      // Aquí iría la llamada al backend para autenticar
    }
  }
  
  // Función para manejar el registro
  function handleRegister() {
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const nameError = document.getElementById('register-name-error');
    const emailError = document.getElementById('register-email-error');
    const passwordError = document.getElementById('register-password-error');
  
    nameError.style.display = 'none';
    emailError.style.display = 'none';
    passwordError.style.display = 'none';
  
    let valid = true;
  
    if (!name) {
      nameError.style.display = 'block';
      valid = false;
    }
  
    if (!validateEmail(email)) {
      emailError.style.display = 'block';
      valid = false;
    }
  
    if (password.length < 6) {
      passwordError.style.display = 'block';
      valid = false;
    }
  
    if (valid) {
      alert('Registro exitoso (simulación). Enviar al backend: ' + name + ', ' + email);
      // Aquí iría la llamada al backend para registrar
    }
  }
  
  // Función para volver a la página anterior
  function goBack() {
    window.history.back();
  }