const navbar = document.getElementById('navbar');
const menuIcon = document.getElementById('menuIcon');
let lastScrollTop = 0;

window.addEventListener('scroll', () => {
    let scrollTop = window.pageYOffset || document.documentElement.scrollTop;

    if (scrollTop > lastScrollTop) {
        // Scrolling hacia abajo
        navbar.classList.add('hidden');
        menuIcon.classList.add('active');
    } else {
        // Scrolling hacia arriba
        navbar.classList.remove('hidden');
        menuIcon.classList.remove('active');
    }
    lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
});

menuIcon.addEventListener('click', () => {
    navbar.classList.remove('hidden');
    menuIcon.classList.remove('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Incidencias
const typeOptions = {
    Infraestructura: ["Daño estructural", "Fuga de agua", "Problema eléctrico"],
    Sistemas: ["Fallo de software", "Problema de red", "Error de hardware"],
    Personal: ["Conflicto laboral", "Ausencia", "Otro"]
};

function updateTypes() {
    const category = document.getElementById("category").value;
    const typeSelect = document.getElementById("type");
    typeSelect.innerHTML = '<option value="">Seleccione Tipo</option>';
    typeSelect.disabled = !category;

    if (category && typeOptions[category]) {
        typeOptions[category].forEach(type => {
            const option = document.createElement("option");
            option.value = type;
            option.text = type;
            typeSelect.appendChild(option);
        });
    }
}

function clearForm() {
    document.getElementById("category").value = "";
    document.getElementById("type").innerHTML = '<option value="">Seleccione Tipo</option>';
    document.getElementById("type").disabled = true;
    document.getElementById("description").value = "";
}

function submitForm() {
    const category = document.getElementById("category").value;
    const type = document.getElementById("type").value;
    const description = document.getElementById("description").value;

    if (!category || !type || !description) {
        alert("Por favor, complete todos los campos.");
        return;
    }

    alert(`Incidencia registrada:\nCategoría: ${category}\nTipo: ${type}\nDescripción: ${description}`);
    clearForm();
}


    document.addEventListener('DOMContentLoaded', () => {
        const menuIcon = document.getElementById('menuIcon');
        const navbar = document.getElementById('navbar');

        menuIcon.addEventListener('click', () => {
            navbar.classList.toggle('active');
            navbar.classList.toggle('hidden');
            menuIcon.textContent = navbar.classList.contains('active') ? '✕' : '☰';
        });

        let lastScrollTop = 0;
        window.addEventListener('scroll', () => {
            const currentScroll = window.pageYOffset || document.documentElement.scrollTop;
            if (currentScroll > lastScrollTop && currentScroll > 100) {
                navbar.classList.add('hidden');
                if (window.innerWidth <= 768) {
                    menuIcon.classList.add('active');
                }
            } else if (currentScroll <= 100 || currentScroll < lastScrollTop) {
                navbar.classList.remove('hidden');
                menuIcon.classList.remove('active');
                navbar.classList.remove('active');
                menuIcon.textContent = '☰';
            }
            lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                navbar.classList.remove('hidden', 'active');
                menuIcon.classList.remove('active');
            }
        });
    });

    Copiar

    document.addEventListener('DOMContentLoaded', () => {
        const menuIcon = document.getElementById('menuIcon');
        const navbar = document.getElementById('navbar');

        if (!menuIcon || !navbar) {
            console.error('Menu icon or navbar not found');
            return;
        }

        menuIcon.addEventListener('click', (e) => {
            e.preventDefault();
            if (navbar.classList.contains('active')) {
                navbar.classList.remove('active');
                navbar.classList.add('hidden');
                menuIcon.textContent = '↑';
                menuIcon.classList.add('scroll-to-top');
            } else if (window.pageYOffset > 100) {
                window.scrollTo({ top: 0, behavior: 'smooth' });
                navbar.classList.add('hidden');
                menuIcon.classList.add('scroll-to-top');
                menuIcon.textContent = '↑';
            } else {
                navbar.classList.add('active');
                navbar.classList.remove('hidden');
                menuIcon.textContent = '✕';
                menuIcon.classList.remove('scroll-to-top');
            }
        });

        let lastScrollTop = 0;
        window.addEventListener('scroll', () => {
            const currentScroll = window.pageYOffset || document.documentElement.scrollTop;
            if (window.innerWidth <= 768) {
                if (currentScroll > lastScrollTop && currentScroll > 100) {
                    navbar.classList.add('hidden');
                    navbar.classList.remove('active');
                    menuIcon.classList.add('active', 'scroll-to-top');
                    menuIcon.textContent = '↑';
                } else {
                    navbar.classList.remove('hidden');
                    navbar.classList.remove('active');
                    menuIcon.classList.remove('active', 'scroll-to-top');
                    menuIcon.textContent = '☰';
                }
            } else {
                navbar.classList.remove('hidden', 'active');
                menuIcon.classList.remove('active', 'scroll-to-top');
                menuIcon.textContent = '☰';
            }
            lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                navbar.classList.remove('hidden', 'active');
                menuIcon.classList.remove('active', 'scroll-to-top');
                menuIcon.textContent = '☰';
            } else {
                navbar.classList.add('hidden');
                navbar.classList.remove('active');
                if (window.pageYOffset > 100) {
                    menuIcon.classList.add('active', 'scroll-to-top');
                    menuIcon.textContent = '↑';
                } else {
                    menuIcon.classList.remove('active', 'scroll-to-top');
                    menuIcon.textContent = '☰';
                }
            }
        });

        if (window.innerWidth <= 768 && window.pageYOffset > 100) {
            navbar.classList.add('hidden');
            menuIcon.classList.add('active', 'scroll-to-top');
            menuIcon.textContent = '↑';
        }
    });
